package quotation;

import java.util.Map;
import java.util.TreeMap;

import com.google.gson.Gson;

import core.ClientInfo;

public class QuotationApplication {
	
	public String name;Map<String, ClientInfo> record = new TreeMap <String, ClientInfo>();
	Gson gson = new Gson();
	
	public char sex;
	public int age;
	public int points;
	public int noClaims;
	public String licenseNumber;
	
	public QuotationApplication (String name, char sex, int age, int points, int noClaims, String licenseNumber) {
		this.name = name;
		this.sex = sex;
		this.age = age;
		this.points = points;
		this.noClaims = noClaims;
		this.licenseNumber = licenseNumber;
	}

	public void merge(ClientInfo info) {
		if(name == null) name= info.name;
		if(sex == null) sex=info.sex;
		if(age == null) age=info.age;
		if(points == null) points=info.points;
		if(noClaims == null) noClaims=info.noClaims;
		if(licenseNumber == null) licenseNumber=info.licenseNumber;
		
	}
	
	public String toString() {
		return name + " = { " + sex + " " + age + ", " + points + ", " + noClaims + ", " + licenseNumber + " }";
	}
}
