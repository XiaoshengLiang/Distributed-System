package quotation;

import java.util.Map;
import java.util.TreeMap;
import org.restlet.Application;
import org.restlet.Component;
import org.restlet.Request;
import org.restlet.Response;
import org.restlet.Restlet;
import org.restlet.data.MediaType;
import org.restlet.data.Method;
import org.restlet.data.Protocol;
import org.restlet.data.Status;
import org.restlet.routing.Router;
import com.google.gson.Gson;

import core.ClientInfo;

public class QuotationServer extends Application{
	
	public static void main(String[] args) throws Exception{
		Component component1 = new Component(); 
		component1.getServers().add(Protocol.HTTP, 8182); 
		component1.getDefaultHost().attach("/afq", new QuotationApplication(new AFQService())); 
		component1.start();
		
		Component component2 = new Component(); 
		component2.getServers().add(Protocol.HTTP, 8183); 
		component2.getDefaultHost().attach("/ddq", new QuotationApplication(new DDQService())); 
		component2.start();
		
		Component component3 = new Component(); 
		component3.getServers().add(Protocol.HTTP, 8184); 
		component3.getDefaultHost().attach("/gpq", new QuotationApplication(new GPQService())); 
		component3.start();
	}
}
