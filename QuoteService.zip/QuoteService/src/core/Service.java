package core;

public interface Service {

}
